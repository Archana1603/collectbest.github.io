package com.worldcollection.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.query.Query;

import com.worldcollection.entities.User;

public class UserDao {
	
	private SessionFactory factory;

	public UserDao(SessionFactory factory) {
		this.factory = factory;
	}
	
	public int saveUser(User user) {
		Session session = this.factory.openSession();
		Transaction tx = session.beginTransaction();
		int id = (Integer) session.save(user);
		tx.commit();
		session.close();
		return id;
	}
	
	public User getEmailAndPassword(String email, String password) {
		User user=null;
		
		try {
			Session session = this.factory.openSession();
			Query query = session.createQuery("from User where email=:e and password=:p");
			query.setParameter("e", email);
			query.setParameter("p", password);
			user = (User) query.uniqueResult();
			session.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return user;
	}
	
	public User getSingleUser(int id) {
		Session s = this.factory.openSession();
		
		User user = s.get(User.class, id);
		
		s.close();
		return user;
	}

	public List<User> getAllUser(){
		Session s = factory.openSession();
		
		Query query = s.createQuery("from User");
		
		List<User> list = query.list();
		
		s.close();
		return list;
	}
	
	public boolean updateUser(int id) {
		boolean f = false;
		try {
		Session session = factory.openSession();
		
		User user = session.get(User.class, id);
		
		session.update(user);
		
		session.close();
		f=true;
		}catch (Exception e) {
			e.printStackTrace();
		}
		return f;
	}
	
	public User deleteUser(int id) {
		Session s = factory.openSession();
		
		User user = s.get(User.class, id);
		
		s.delete(user);
		
		s.close();
		
		return user;
	}
	
}
