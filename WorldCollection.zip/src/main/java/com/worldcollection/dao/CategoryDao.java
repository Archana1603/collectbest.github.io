package com.worldcollection.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.query.Query;

import com.worldcollection.entities.Category;

public class CategoryDao {
	
	public SessionFactory factory;

	public CategoryDao(SessionFactory factory) {
		this.factory = factory;
	}
	
	public int saveCategory(Category category) {
		Session session = factory.openSession();
		
		Transaction tx = session.beginTransaction();
		
		int id = (Integer)session.save(category);
		
		tx.commit();
		
		session.close();
		
		return id;
		
	}
	
	public Category getCategoryById(int catId) {
		Session session = factory.openSession();
		
		Category category = session.get(Category.class, catId);
		
		session.close();
		return category;
	}
	public List<Category> getAllCategory() {
		Session session = factory.openSession();
		
		Query query = session.createQuery("from Category");
		
		List<Category> list = query.list();
		
		session.close();
		return list;
	}
	
	public boolean deleteCategory(int catId) {
		
		boolean f = false;
		
		try {
			
			Session session = factory.openSession();
			
			Query query = session.createQuery("delete from Category as a where a.catId=:c");
			
		    query.setParameter("c", catId);
			
			query.executeUpdate();
			
			session.close();
			
			f=true;
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		return f;
	}
	
	public boolean UpdateCategory(Category cat , int catId) {
		
		boolean f = false;
		
		try {
			
			Session session = factory.openSession();
			Transaction tx = session.beginTransaction();
			Category category = session.get(Category.class, catId);
			
			category.setCatDescription(cat.getCatDescription());
			category.setCatTitle(cat.getCatTitle());
			
			session.update(category);
			tx.commit();
			session.close();
			
			f=true;
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		return f;
	}
	

}
