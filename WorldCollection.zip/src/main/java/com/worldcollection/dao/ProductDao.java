package com.worldcollection.dao;


import java.io.Serializable;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.query.Query;

import com.worldcollection.entities.Category;
import com.worldcollection.entities.Product;

public class ProductDao {
	
	SessionFactory factory;

	public ProductDao(SessionFactory factory) {
		this.factory = factory;
	}
	
	public int saveProduct(Product p) {
		Session session = this.factory.openSession();
		
		Transaction tx = session.beginTransaction();
		
		int pid = (Integer)session.save(p);
		
		tx.commit();
		session.close();
		
		return pid;
	}
	
	public List<Product> getAllProducts(){
		Session session = factory.openSession();
		
		Query query = session.createQuery("from Product");
		List<Product> list = query.list();
		
		session.close();
		return list;
	}
public boolean UpdateProduct(Product pro , int pId) {
		
		boolean f = false;
		
		try {
			
			Session session = factory.openSession();
			Transaction tx = session.beginTransaction();
			Product prod = session.get(Product.class, pId);
			
			prod.setName(pro.getName());
			prod.setDescription(pro.getDescription());
			prod.setImage(pro.getImage());
			prod.setOffer(pro.getOffer());
			prod.setPrice(pro.getPrice());
			prod.setStock(pro.getStock());
			prod.setCategory(pro.getCategory());
						
			session.update(prod);
			
			tx.commit();
			session.close();
			
			f=true;
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		return f;
	}

}
