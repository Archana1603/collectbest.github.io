package com.worldcollection.servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.worldcollection.dao.CategoryDao;
import com.worldcollection.entities.Category;
import com.worldcollection.helper.FactoryProvider;

/**
 * Servlet implementation class DeleteServlet
 */
public class DeleteCategory extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		
		int id = Integer.parseInt(request.getParameter("id").trim());

		Session s = FactoryProvider.getFactory().openSession();
		
		Category category = s.get(Category.class, id);
		
		Transaction tx = s.beginTransaction();
		
		s.delete(category);
		
		tx.commit();
		
		s.close();
			HttpSession session = request.getSession();

			session.setAttribute("message", "Category is deleted..!!");

			response.sendRedirect("admin/addcategory.jsp");
		

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
