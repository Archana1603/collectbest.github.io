package com.worldcollection.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.worldcollection.dao.CategoryDao;
import com.worldcollection.entities.Category;
import com.worldcollection.helper.FactoryProvider;

/**
 * Servlet implementation class AddCategoryServlet
 */
public class AddCategoryServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public AddCategoryServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	@SuppressWarnings("unlikely-arg-type")
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		response.setContentType("text/html");

		PrintWriter out = response.getWriter();
		try {
			String title = request.getParameter("cname");
			String desc = request.getParameter("cdescription");

			Category cat = new Category();

			cat.setCatDescription(desc);
			cat.setCatTitle(title);

			CategoryDao catDao = new CategoryDao(FactoryProvider.getFactory());

			HttpSession session = request.getSession();
			int i = catDao.saveCategory(cat);
		
			if (i > 0) {
				session.setAttribute("message", "Add category successfully..!!");
				response.sendRedirect("admin/addcategory.jsp");
			} else {
				session.setAttribute("danger", "Category has not been added..!!");
				response.sendRedirect("admin/addcategory.jsp");
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		out.print("Success");

	}

}
