package com.worldcollection.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.worldcollection.dao.UserDao;
import com.worldcollection.entities.User;
import com.worldcollection.helper.FactoryProvider;

/**
 * Servlet implementation class SignUpServlet
 */
public class SignUpServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public SignUpServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		response.setContentType("text/html");

		PrintWriter out = response.getWriter();

		String name = request.getParameter("name");
		String email = request.getParameter("email");
		String pass = request.getParameter("password");
		String add = request.getParameter("address");
		String phone = request.getParameter("phone");
		
		try {
		
		User user = new User();
		
		user.setAddress(add);
		user.setEmail(email);
		user.setPassword(pass);
		user.setPhone(phone);
		user.setName(name);
		user.setUserType("User");
				
		UserDao userDao = new UserDao(FactoryProvider.getFactory());

		int i = userDao.saveUser(user);

		out.println("Successfully done..!!");

		HttpSession session = request.getSession();

		if(name.isBlank() && email.isBlank() && email.isBlank() && pass.isBlank() && phone.isBlank()) {
			HttpSession se = request.getSession();
			se.setAttribute("danger", "Fill Up required Details..!!");
			response.sendRedirect("register.jsp");
		}else {		
		if (i > 0) {
			session.setAttribute("message", "Successfully you are signed up..!!");
			response.sendRedirect("login.jsp");
		} else {
			session.setAttribute("danger", "Something went wrong Try again..!!");
			response.sendRedirect("register.jsp");
		}
		}
		}catch (Exception e) {
			e.printStackTrace();
		}

	}

}
