package com.worldcollection.servlet;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.servlet.http.Part;

import com.worldcollection.dao.CategoryDao;
import com.worldcollection.dao.ProductDao;
import com.worldcollection.entities.Category;
import com.worldcollection.entities.Product;
import com.worldcollection.helper.FactoryProvider;

/**
 * Servlet implementation class UpdateProduct
 */
@MultipartConfig
public class UpdateProduct extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public UpdateProduct() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {


		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		
		
		String name = request.getParameter("pName");
		int price = Integer.parseInt(request.getParameter("pPrice"));
		int stock = Integer.parseInt(request.getParameter("pStock"));
		int off = Integer.parseInt(request.getParameter("pOff"));
		String desc = request.getParameter("pDesc");
		int catId = Integer.parseInt(request.getParameter("catId"));
		Part part = request.getPart("pImage");

		int pid = Integer.parseInt(request.getParameter("pId"));

		
		Product p = new Product();

		p.setDescription(desc);
		p.setImage(part.getSubmittedFileName());
		p.setName(name);
		p.setOffer(off);
		p.setPrice(price);
		p.setStock(stock);
		p.setId(pid);

		CategoryDao catdao = new CategoryDao(FactoryProvider.getFactory());

		Category category = catdao.getCategoryById(catId);

		p.setCategory(category);

		ProductDao pdao = new ProductDao(FactoryProvider.getFactory());

		boolean product = pdao.UpdateProduct(p, pid);

		String path = request.getRealPath("image") + File.separator + "products" + File.separator
				+ part.getSubmittedFileName();
		
		try {

			FileOutputStream fos = new FileOutputStream(path);

			InputStream is = part.getInputStream();

			byte[] data = new byte[is.available()];

			is.read(data);

			fos.write(data);
			fos.close();
			
			

		} catch (Exception e) {
			e.printStackTrace();
		}

		if (product) {
			out.print("saved..!!");
			HttpSession session = request.getSession();
			session.setAttribute("message", "Product is updated successfully..!!");
			response.sendRedirect("admin/manageproduct.jsp");
			return;
		} else {
			HttpSession session = request.getSession();
			session.setAttribute("danger", "Product is not updated Try again..!!");
			response.sendRedirect("admin/manageproduct.jsp");
		}
	}

}
