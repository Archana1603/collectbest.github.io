package com.worldcollection.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.worldcollection.dao.CategoryDao;
import com.worldcollection.entities.Category;
import com.worldcollection.helper.FactoryProvider;

/**
 * Servlet implementation class UpdateCategoryServlet
 */
public class UpdateCategoryServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public UpdateCategoryServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		PrintWriter out = response.getWriter();
		response.setContentType("text/html");

		int id = Integer.parseInt(request.getParameter("id"));
		String title = request.getParameter("cname");
		String desc = request.getParameter("cdescription");

		Category cat = new Category();

		cat.setCatDescription(desc);
		cat.setCatTitle(title);
		cat.setCatId(id);

		CategoryDao catDao = new CategoryDao(FactoryProvider.getFactory());

		boolean category = catDao.UpdateCategory(cat, id);

		if (category) {
			HttpSession session = request.getSession();

			session.setAttribute("message", "Category is updated successfully..!!");

			response.sendRedirect("admin/addcategory.jsp");
		} else {
			HttpSession session = request.getSession();

			session.setAttribute("danger", "Category is not updated try again..!!");

			response.sendRedirect("admin/addcategory.jsp");
		}

	}

}
