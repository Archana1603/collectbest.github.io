package com.worldcollection.entities;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;

@Entity
public class Category {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	int catId;
	String catTitle;
	String catDescription;
	@OneToMany(mappedBy = "category")
	List<Product> product = new ArrayList<Product>();
	public List<Product> getProduct() {
		return product;
	}
	public void setProduct(List<Product> product) {
		this.product = product;
	}
	public Category() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Category(int catId, String catTitle, String catDescription) {
		super();
		this.catId = catId;
		this.catTitle = catTitle;
		this.catDescription = catDescription;
	}
	public int getCatId() {
		return catId;
	}
	public void setCatId(int catId) {
		this.catId = catId;
	}
	public String getCatTitle() {
		return catTitle;
	}
	public void setCatTitle(String catTitle) {
		this.catTitle = catTitle;
	}
	public String getCatDescription() {
		return catDescription;
	}
	public void setCatDescription(String catDescription) {
		this.catDescription = catDescription;
	}
	@Override
	public String toString() {
		return "Category [catId=" + catId + ", catTitle=" + catTitle + ", catDescription=" + catDescription + "]";
	}
	
	
	
}
